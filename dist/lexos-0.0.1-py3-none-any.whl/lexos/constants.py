"""constants.py.

Lexos constants.
"""
# Numbers
MIN_ENCODING_DETECT = 10000
