# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lexos',
 'lexos.cluster',
 'lexos.corpus',
 'lexos.cutter',
 'lexos.dtm',
 'lexos.io',
 'lexos.language_model',
 'lexos.scrubber',
 'lexos.tokenizer',
 'lexos.topic_model',
 'lexos.topic_model.dfr_browser',
 'lexos.topic_model.mallet',
 'lexos.visualization',
 'lexos.visualization.bubbleviz',
 'lexos.visualization.cloud',
 'lexos.visualization.plotly',
 'lexos.visualization.plotly.cloud',
 'lexos.visualization.plotly.cluster',
 'lexos.visualization.seaborn',
 'lexos.visualization.seaborn.cluster']

package_data = \
{'': ['*'],
 'lexos.language_model': ['recipes/*'],
 'lexos.topic_model': ['dfr_browser/template/*',
                       'dfr_browser/template/bin/*',
                       'dfr_browser/template/css/*',
                       'dfr_browser/template/fonts/*',
                       'dfr_browser/template/js/*',
                       'dfr_browser/template/lib/*']}

install_requires = \
['beautifulsoup4>=4.11.1,<5.0.0',
 'catalogue>=2.0.7,<3.0.0',
 'chardet>=4.0.0,<5.0.0',
 'cytoolz>=0.11.2,<0.12.0',
 'docx2txt>=0.8,<0.9',
 'gensim>=4.2.0,<5.0.0',
 'natsort>=8.1.0,<9.0.0',
 'openpyxl>=3.0.10,<4.0.0',
 'pandas>=1.4.2,<2.0.0',
 'pdfminer.six>=20220524,<20220525',
 'plotly>=5.9.0,<6.0.0',
 'pyLDAvis>=3.3.1,<4.0.0',
 'requests>=2.28.0,<3.0.0',
 'rich>=12.4.4,<13.0.0',
 'scipy>=1.8.1,<2.0.0',
 'seaborn>=0.11.2,<0.12.0',
 'spacy>=3.4.0,<3.5.0',
 'textacy>=0.12.0,<0.13.0',
 'typer>=0.4.1,<0.5.0',
 'wordcloud>=1.8.1,<2.0.0']

setup_kwargs = {
    'name': 'lexos',
    'version': '0.0.1',
    'description': 'Lexos is a tool for the analysis of lexical data. The Lexos package is the Python API for the Lexos tool.',
    'long_description': None,
    'author': 'Scott Kleinman',
    'author_email': 'scott.kleinman@csun.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
