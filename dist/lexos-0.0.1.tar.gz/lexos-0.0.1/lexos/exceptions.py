"""exceptions.py.

LexosException class.
"""

class LexosException(Exception):
    """Base class for all exceptions in Lexos."""
    pass
