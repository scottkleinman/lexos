"""__init__.py."""

__version__ = "0.0.1"
__docs__ = "https://scottkleinman.github.io/lexos/"
__repo__ = "https://github.com/scottkleinman/lexos"
