# README

This sample dataset is taken from David Bamman's [LitBank](https://github.com/dbamman/litbank) annotated dataset of 100 works of English-language fiction intended to support tasks in natural language processing and the computational humanities. LitBank is licensed under a [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).

The sample dataset for this tutorial contains only the original texts and metadata without any of the associated annotations.
